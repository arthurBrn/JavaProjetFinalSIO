package vue;

import modele.medicament;

public class JIFMedicamentFiche extends JIFMedicament {

	private static final long serialVersionUID = 1L;

	public JIFMedicamentFiche(medicament unMedicament) {
		super();
		this.remplirText(unMedicament);

	}
	

}
