/*
 * Cr�� le 2 mars 2015
 *
 * TODO Pour changer le mod�le de ce fichier g�n�r�, allez � :
 * Fen�tre - Pr�f�rences - Java - Style de code - Mod�les de code
 */
package vue;



import modele.Medecin;

/**
 * @author Isabelle
 * 2 mars 2015
 * TODO Pour changer le mod�le de ce commentaire de type g�n�r�, allez � :
 * Fen�tre - Pr�f�rences - Java - Style de code - Mod�les de code
 */
public class JIFMedecinFiche extends JIFMedecin {

	private static final long serialVersionUID = 1L;

	public JIFMedecinFiche(Medecin unMedecin) {
		super();
		this.remplirText(unMedecin);

	}
	

}
