package vue;

import java.awt.Container;


import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import modele.medicament;
import modele.dao.medicamentDao;

public class JIFMedicamentAjout extends JInternalFrame implements ActionListener{
   
    private static final long serialVersionUID = 1L;
   
    protected JPanel a;
    protected JPanel aBouton;
    protected JPanel aTexte;
   
   
    protected JLabel JLcodeVisiteur;
    protected JLabel JLdepotLegal;
    protected JLabel JLquantite;
   
    protected JTextField JTcodeVisiteur;
    protected JTextField JTdepotLegal;
    protected JTextField JTquantite;
    
    protected JButton JBajouterQuantite;

    public JIFMedicamentAjout(){
        a = new JPanel();  // panneau principal de la fen�tre
        aBouton = new JPanel();    // panneau supportant les boutons
        aTexte = new JPanel(new GridLayout(8,2));
       
        JLcodeVisiteur = new JLabel("Code visiteur");
        JLdepotLegal = new JLabel("D�pot l�gal");
        JLquantite = new JLabel("Quantit�");
       
        JTcodeVisiteur = new JTextField(20);
        JTdepotLegal= new JTextField();
        JTquantite = new JTextField();
       
        aTexte.add(JLcodeVisiteur);
        aTexte.add(JTcodeVisiteur);
        aTexte.add(JLdepotLegal);
        aTexte.add(JTdepotLegal);
        aTexte.add(JLquantite);
        aTexte.add(JTquantite);
       
        //Mise en forme du texte
       
        a.add(aTexte);
        a.add(aBouton);
        Container contentPane = getContentPane();
        contentPane.add(a);
       
        JBajouterQuantite = new JButton("Ajouter quantit�");
        aBouton.add(JBajouterQuantite);    
        JBajouterQuantite.addActionListener(this);
    }
    public void actionPerformed(ActionEvent arg0) {

    	Object source = arg0.getSource();

    	if (source == JBajouterQuantite){

    	medicament unMedicament = medicamentDao.ajouterMedicament(JTcodeVisiteur.getText());

    	}

    	}

}