/*
 * Cr�� le 23 f�vr. 2015
 *
 * TODO Pour changer le mod�le de ce fichier g�n�r�, allez � :
 * Fen�tre - Pr�f�rences - Java - Style de code - Mod�les de code
 */
package tests;

import modele.Medecin;

import service.MedecinService;

/**
 * @author Isabelle
 * 23 f�vr. 2015
 * TODO Pour changer le mod�le de ce commentaire de type g�n�r�, allez � :
 * Fen�tre - Pr�f�rences - Java - Style de code - Mod�les de code
 */
public class MedecinServiceTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Medecin unMedecin = MedecinService.rechercherMedecin("m002");
		System.out.println(unMedecin.getNomPersonne());
		System.out.println(unMedecin.getPrenomPersonne());
		System.out.println(unMedecin.getAdresse());
		System.out.println(unMedecin.getUneLocalite().getCodePostal());
		System.out.println(unMedecin.getUneLocalite().getVille());
		System.out.println(unMedecin.getTelephone());
		System.out.println(unMedecin.getPotentiel());
		System.out.println(unMedecin.getLaSpecialite());
		
		

	}

}
