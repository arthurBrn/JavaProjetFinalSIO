/*
 * Cr�� le 22 f�vr. 2015
 *
 * TODO Pour changer le mod�le de ce fichier g�n�r�, allez � :
 * Fen�tre - Pr�f�rences - Java - Style de code - Mod�les de code
 */
package tests;

import vue.MenuPrincipal;

/**
 * @author Isabelle
 * 22 f�vr. 2015
 * TODO Pour changer le mod�le de ce commentaire de type g�n�r�, allez � :
 * Fen�tre - Pr�f�rences - Java - Style de code - Mod�les de code
 */
public class Application {

	public static void main(String[] args) {
		
		MenuPrincipal application;
		application = new MenuPrincipal();// TODO Raccord de m�thode auto-g�n�r�
		application.setTitle("GSBJAVA");
	}

}
