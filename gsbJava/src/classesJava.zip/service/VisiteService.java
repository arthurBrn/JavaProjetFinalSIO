package service;


import modele.visite;

import modele.dao.MedecinDao;
import modele.dao.visiteurDao;
import modele.dao.visiteDao;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import modele.Medecin;
import modele.visiteur;

import modele.dao.MedecinDao;

public class VisiteService {

		
	public static boolean verification(String reference, String dateVisite, String commentaire, String matriculeVisiteur,
			String codeMedecin) {
		boolean reussi = false;

		try {

			if (reference.isEmpty() || dateVisite.isEmpty() || matriculeVisiteur.isEmpty() || codeMedecin.isEmpty()) {
				throw new Exception("Champs obligatoires : reference, date visite, matricule visiteur, code medecin");
			}

			Medecin med = MedecinDao.rechercher(codeMedecin);

			if (med == null) {
				throw new Exception("Code medecin non valide");
			}

			visiteur per = visiteurDao.rechercher(matriculeVisiteur);

			if (per == null) {
				throw new Exception("Matricule visiteur non valide");
			}

			reussi = true;

		} catch (Exception e) {
			JOptionPane.showMessageDialog(new JFrame(), e.getMessage(), "Erreur de saisis", JOptionPane.ERROR_MESSAGE);
		}

		return reussi;
	}
		
		
		/*
		 * Est plac� dans la vue JIFAjoutVisite
		 * Sert � v�rifier qu'aucun champ de la vue n'est null
		 * */
		/* public static boolean ajouterVisiteVerification(visite uneVisite) {
			boolean insertion = false;
			Medecin unMedecin = null;
			visiteur unVisiteur = null;
			try {
				if(uneVisite.getReference() == null) 
					throw new Exception("Donn�e obligatoire : reference");
				if(uneVisite.getDate() == null) 
					throw new Exception("Donn�e obligatoire : Date");
				if(uneVisite.getCommentaire() == null)
					throw new Exception("Donn�e obligatoire : Commentaire");
				
				// V�rifier que le champ matricule du visiteur n'est pas null
				//Si oui lance exception "Matricule"
				if(unVisiteur.getMatricule() == null) //Faire un lien vers visiteur
					throw new Exception("Donn�e obligatoire : Matricule");
				
				
				//R�cup�re codeMedecin
				if(unMedecin.getCodeMed() == null)
					throw new Exception("Donn�e obligatoire : code");
				
				
				
			//insertion = visiteDao.ajouterVisite(uneVisite);
			}
			catch(Exception e) {
				System.out.println(e.getMessage());
				System.out.println("Erreur m�thode ajouterVisiteVerification dans ajoutVisiteService");
			}
			return insertion;
		}*/
	}
	
	


