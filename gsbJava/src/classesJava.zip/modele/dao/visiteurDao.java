package modele.dao;

import java.sql.ResultSet;



import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import modele.Localite;
import modele.Personne;
import modele.visiteur;
import modele.dao.PersonneDao;
/*
 * vir� code personne des deux tables 
 * passer code med et matricule en cl� �trang�re 
 * 
 * finir constructeur isiteur DAO
 * 
 * */


public class visiteurDao {
	public static visiteur rechercher(String codePersonne){
		visiteur unVisiteur=null;
		Localite uneLocalite= null;
		ResultSet reqSelection = ConnexionMySql.execReqSelection("SELECT MATRICULE, VISITEUR_LOGIN, VISITEUR_MDP, VISITEUR_DATEENTREE, LOC_CODEPOSTAL, LOC_VILLE"
				+ " FROM visiteur INNER personne ON visiteur.matricule = personne.codepersonne WHERE MATRICULE ='"+codePersonne+"'");
		try {
			if (reqSelection.next()) {
				// probl�me ici
				uneLocalite = LocaliteDao.rechercher(reqSelection.getString(8), reqSelection.getString(9));
				// unePersonne = PersonneDao.rechercher(reqSelection.getString(1));
				unVisiteur= new visiteur(reqSelection.getString("codePersonne"), reqSelection.getString("login"), 
						reqSelection.getString("mdp"), 
						reqSelection.getString("dateEntree"),
						reqSelection.getString("nomPersonne"), reqSelection.getString("prenomPersonne"), reqSelection.getString("adresse"), uneLocalite);	
			};// utilis� des setters + clair 
			
			
			}
		catch(Exception e) {
			System.out.println("erreur reqSelection.next() pour la requ�te - SELECT * FROM visiteur WHERE MATRICULE ='"+codePersonne+"'");
			e.printStackTrace();
			}
		ConnexionMySql.fermerConnexionBd();
		return unVisiteur;
	}
	
	public static ArrayList<visiteur> retournerCollectionDesVisiteurs(){
		ArrayList<visiteur> collectionDesVisiteurs = new ArrayList<visiteur>();
		ResultSet reqSelection = ConnexionMySql.execReqSelection("select MATRICULE from visiteur");
		try{
		while (reqSelection.next()) {
			String matricule = reqSelection.getString(1);
		    collectionDesVisiteurs.add(visiteurDao.rechercher(matricule));
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
			System.out.println("erreur retournerCollectionDesVisiteurs()");
		}
		return collectionDesVisiteurs;
	}
	
	public static HashMap<String,visiteur> retournerDictionnaireDesVisiteurs(){
		HashMap<String, visiteur> diccoDesVisiteurs = new HashMap<String, visiteur>();
		ResultSet reqSelection = ConnexionMySql.execReqSelection("select MATRICULE from visiteur");
		try{
		while (reqSelection.next()) {
			String matricule = reqSelection.getString(1);
		    diccoDesVisiteurs.put(matricule, visiteurDao.rechercher(matricule));
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
			System.out.println("erreur retournerDiccoDesVisiteurs()");
		}
		return diccoDesVisiteurs;
	}

	public static int ajouterVisiteur(visiteur unVisiteur) {
		// TODO Auto-generated method stub
		return 0;
	}
}
